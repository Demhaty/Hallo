<?php
@include 'session.php';
//session_start();
//abmelden
if(isset($_REQUEST['abmelden']))
{

    echo '<div class="alert alert-warning" role="alert">Willst du abmelden!
    <a href="abmelden.php?benutzerID='.$_SESSION['id'].'"  class="btn btn-outline-dark" style="width: 50px; text-align:center;">JA</a>
    <a href="index4.php"  class="btn btn-outline-dark" style="width: 60px;text-align:center;">NEIN</a>
    </div>';

}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Blog</title>       
        <!-- CSS only -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <form method="post" action="index4.php">
    <div class="mx-auto" style="width: 800px; margin-top: 20px;">
        <label for="exampleFormControlTextarea1" class="form-label">Blog</label>
        <textarea type="text" name="blog" class="form-control" id="exampleFormControlTextarea1"  rows="3"></textarea>
        <button type="submit" name="blog_senden" class="btn btn-secondary" style="margin-top: 10px;">Send</button> 
        <button type="submit" name="abmelden" class="btn btn-warning position-absolute top-0 end-0" style="margin-top:10px">Abmelden</button>
      
    </div>
    </form>
    <table class="table thead-dark table-striped table-bordered table-responsive-lg" style=" margin-top:100px; ">
        <thead>
            <tr>
            <th scope="col">Gesamt_Blog für Benutzer_ID<?php echo $_SESSION['id']; ?></th>
            <th scope="col" style="width:50px">Blog_nummer</th>
            <th scope="col" style="width:500px">Blog</th>
            <th scope="col">Datum</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
<?php
//print_r($_SESSION);
//include 'session.php';
//insert für Blog 
function insert_blog(){
    
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "projekt";
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) 
    {
        die("Connection failed: " . $conn->connect_error);
    }
    $stmt_blogg=$conn->prepare("INSERT INTO blogg
    (fkk_benutzer_ID,blog,col_date) VALUES (?,?,?)");
    $stmt_blogg->bind_param("iss",$_SESSION['id'],$blog,$date);
    $blog=$_REQUEST['blog'];
    $date=date("Y.m.d H:i:s");
    $stmt_blogg->execute();
    $stmt_blogg->close();
    $conn->close();
    show_blog();  

}

//Um Blog gezeigt
function show_blog()
{
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "projekt";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) 
    {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql_blog="SELECT blog_nummer,blog,col_date FROM blogg WHERE fkk_benutzer_ID='".$_SESSION['id']."' ORDER BY(blog_nummer) DESC";
    $result_blog=$conn->query($sql_blog);
    if($result_blog->num_rows>0)
    {
        $i = 0;
        while($row=$result_blog->fetch_assoc())
        {
                $arr_bolgID[$i]=$row['blog_nummer'];
                $a[$i]=$row['blog'];
                $b[$i]=$row['col_date'];
                $i++;
        }
        $total = $i ;
        $_SESSION['total']=$total;
        $i=0;
        for($j=0;$j<$total;$j++)
        {
            /*$q='{"row"}';
            $q1='"button"';
            $q2='"btn btn btn-danger"';
            $q3='"delete.php"';*/
            $var= '<tr>
            <th scope="row">'.($i=$i+1).'</th>
            <td> '.$arr_bolgID[$j].'</td> 
            <td> '.$a[$j].'</td>
            <td> '.$b[$j].'</td> 
            
            <td><a href="delete.php? delete_blogid='.$arr_bolgID[$j].'" class="btn btn-outline-danger">DELETE</a>
            <a href="update.php? update_blogid='.$arr_bolgID[$j].'" class="btn btn-outline-primary">UPDATE</a></td>
            </tr>';
            echo $var;  
        }
        //print_r($b); 
    }
    //$conn->close();
}

if(isset($_REQUEST['blog_senden']))
{
    if(!empty($_REQUEST['blog']))
    {
        
        insert_blog();
        
        ?>
        <div class="alert alert-success" role="alert">Das Blog wurde gepostet!</div>
        <?php

    }
    else{?>
        <div class="alert alert-danger" role="alert">Bitte geben Sie das Blog ein!</div>
            
    <?php    
    }   
}
else{
    show_blog();  
}
//echo $_SESSION['total']."</br>";
echo $_SESSION['id'].":BenutzerID</br>";
//echo $_SESSION['total'].":Wie viele daten</br>";
$seiten_ausgaben=ceil($_SESSION['total']/7);
$_SESSION['numberr']=$seiten_ausgaben;
//echo $seiten_ausgaben;
for($i=0;$i<$seiten_ausgaben;$i++)
{        
    echo
    '</tbody>
    </table>

    <a href="seiten.php? button_nummer='.($i+1).'" class="btn btn-outline-info" style="text-align:center;">'.($i+1).'</a>';
}
?>
</body>
</html>


