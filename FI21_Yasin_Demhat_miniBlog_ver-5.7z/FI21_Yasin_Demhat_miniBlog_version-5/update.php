<?php
@include 'session.php';
?>
<!DOCTYPE html>
<html>
    <head>
        <title>UPDATE_Blog</title>       
        
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
        <form method="post">
    <div class="mx-auto" style="width: 800px; margin-top: 20px;">
        <label for="exampleFormControlTextarea1" class="form-label">neu Blog</label>
        <textarea type="text" name="neu_Blog" value="" class="form-control" id="exampleFormControlTextarea1"  rows="3"></textarea>
        <button type="submit" name="neu_Blog_senden" class="btn btn-secondary" style="margin-top: 10px;">neu Blog senden</button>
    </div>
    </form>



<?php
echo $_REQUEST['update_blogid'];
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projekt";


$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
}
if(isset($_REQUEST['update_blogid']))
{
    if(isset($_REQUEST['neu_Blog_senden']))
    {
        if(!empty($_REQUEST['neu_Blog']))
        {
            //$text=$_REQUEST['update_blog_text'];
            $update_blog_nummer=$_REQUEST['update_blogid'];
            $neu_blog=$_REQUEST['neu_Blog'];
            $update_blog = $conn->prepare("UPDATE blogg SET blog=(?) WHERE blog_nummer=(?)");
            $update_blog->bind_param("si",$neu_blog,$update_blog_nummer);
            $update_blog->execute();
            
            //echo "Das Blog mit den Nummer:".$update_blog_nummer." wurde erfolglich korrigiert";
            //header('location:index4.php');
            
            header("Location: index4.php");
        }
    }
}
else{
    echo '<div class="alert alert-danger" role="alert" style="z-index:10;">Bitte Blog eingeben!</div>';
}
?>
</body>
</html>