<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<?php
@include 'session.php';
//Beim anmeldung prüft,ob die E-mail und Passwort richtig sind
function singin()
{
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "projekt";
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) 
    {
        die("Connection failed: " . $conn->connect_error);
        
    }
    $email = $_POST["email"];
    $password = $_POST["password"];
    $hash = hash("sha256", $password);
    $sql_id="SELECT fk_benutzer_ID FROM anmeldung WHERE email='".$_POST['email']."' AND pasd='".$hash."'";
    if(isset($_POST['anmelden']))
    {
        if(!empty($_POST['email']) && !empty($_POST['password']))
        {
            $result = $conn->query($sql_id);
            $row = $result->fetch_assoc();
            if(!$result || !$row) {
                die("error in sql-query". $conn->error);
            }
            $_SESSION['id']= $row['fk_benutzer_ID'];
            //print_r( $_SESSION);
        }
    }
    $sql = "SELECT count(*) as total,email,pasd FROM anmeldung WHERE email='".$_POST['email']."' AND pasd='".$hash."'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) 
        {
            
            while($row = $result->fetch_assoc()) 
            {
                if($row['total']>0)
                {
                    return 1;
                    
                }
                else
                {
                    return 0;
                }
                    
            }
        }    
}
//Beim anmeldung prüft ,ob die button geklickt oder die felder leer sind
function pruf()
{
    if(isset($_POST['anmelden']))
    {
        if(empty($_POST['email']) || empty($_POST['password']))
        {
            
            return 0;     
        }

        if(singin() == 1)
        {
           return 1;
        }    
    }
}
if(pruf()==1) {
   echo '<div class="alert alert-success" role="alert">Super,du wurdest angemeldet!</div>';
    include("index4.php");  
}
else {
    echo '<div class="alert alert-danger" role="alert" style="z-index:10;">Bitte E-mail und Passwort eingeben!</div>';
    include("index.php");
}
?>