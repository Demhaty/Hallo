<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<?php
@include 'session.php';
//Beim Registrierung werden die daten in mysql Tabellen ausgefüllt
function insert_table()
{
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "projekt";
    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) 
    {
        die("Connection failed: " . $conn->connect_error);
    }
    //tabelle Benutzer
    $stmt=$conn->prepare("INSERT INTO benutzer
    (vorname,nachname,geburtsdatum) VALUES (?,?,?)");
    $stmt->bind_param("sss",$vorname,$nachname,$geburtsdatum);
   // $benuzter_ID=$i+1;
    $vorname=$_POST['vorname'];
    $nachname=$_POST['nachname'];
    $geburtsdatum=$_POST['geburtsdatum'];
    $stmt->execute();

    $benutzer_ID = $conn->insert_id;
    $_SESSION['id']=$conn->insert_id;

    //tabelle plz
    $stmt_plz=$conn->prepare("INSERT INTO plz
    (plz_ID,PLZ,ort) VALUES(?,?,?)");
    $stmt_plz->bind_param("iis",$plz_ID,$plz,$ort);
    $plz_ID=$benutzer_ID;
    $plz=$_POST['plz'];
    $ort=$_POST['land'];
    $stmt_plz->execute();
    //tabelle adresse
    $stmt_adresse=$conn->prepare("INSERT INTO adresse
    (adresse_ID,strasse,hausnummer,fk_plz_ID) values(?,?,?,?)");
    $stmt_adresse->bind_param("issi",$adresse_ID,$strasse,$hausnummer,$fk_plz_ID);
    $adresse_ID=$benutzer_ID;
    $fk_plz_ID=$plz_ID;
    $strasse=$_POST['strasse'];
    $hausnummer=$_POST['hausnummer'];
    $stmt_adresse->execute();  
    //tabelle anmeldung
    $stmt_anmeldung=$conn->prepare("INSERT INTO anmeldung
    (fk_benutzer_ID,email,pasd) VALUES (?,?,?)");
    $stmt_anmeldung->bind_param("iss",$benutzer_ID ,$email, $pasd);
    //$fk_benutzer_ID=$benutzer_ID;
    $email=$_POST['email'];
    $password = $_POST["password"];
    $pasd=hash("sha256", $password);
    $stmt_anmeldung->execute();
    
    return 1;

    $stmt->close();
    $stmt_anmeldung->close();
    $stmt_plz->close();
    $stmt_adresse->close();
    
    $conn->close();
}
//Prüft die Registrierung felder
function pruf2()
{
    if(isset($_POST['signup']))
    {
        if((empty($_POST['vorname']) || empty($_POST['nachname']) || empty($_POST['geburtsdatum']) || empty($_POST['land'])
        || empty($_POST['plz']) || empty($_POST['strasse']) ||empty($_POST['hausnummer']) ||empty($_POST['email'])
        ||empty($_POST['password'])||empty($_POST['passwordbe']))|| ($_POST['password']!=$_POST['passwordbe']))
        {
            return 0;
        }
        else
        {
            return 1;
        }
    }
}
if(pruf2()==1)
{
    if(insert_table()==1)
    {
        echo '<div class="alert alert-success" role="alert" style=" z-index:10;">Du hast bei uns registriert!</div>';
        include("index4.php");
    }
}
else
{
    include("index.php");
    echo '<div class="alert alert-danger" role="alert" style=" z-index:6; top:20px">Bitte dein Information eingeben!</div>';
}
?>