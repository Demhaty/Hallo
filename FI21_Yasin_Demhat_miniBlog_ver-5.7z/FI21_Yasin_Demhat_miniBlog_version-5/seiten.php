<?php
@include 'session.php';
?>

<!DOCTYPE html>
<html>
    <head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body>
       
    <table class="table thead-dark table-striped table-bordered table-responsive-lg" style=" margin-top:100px;">
        <thead>
            <tr>
            <th scope="col">Gesamt_Blog für Benutzer_ID<?php echo $_SESSION['id']; ?></th>
            <th scope="col" style="width:500px">Blog</th>
            <th scope="col">Datum</th>
            <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>  
        
<?php

echo $_SESSION['id'].":BenutzerID</br>";
if(isset($_REQUEST['button_nummer']))
{
    $seite_nummer=$_REQUEST['button_nummer'];
    echo $_SESSION['total'].": wie viele blog hat</br>";
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "projekt";
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) 
    {
        die("Connection failed: " . $conn->connect_error);
    }
    $sql_blog="SELECT blog_nummer,blog,col_date FROM blogg WHERE fkk_benutzer_ID='".$_SESSION['id']."' ORDER BY(blog_nummer) DESC";
    $result_blog=$conn->query($sql_blog);
    if($result_blog->num_rows>0)
    {
        $i = 0;
        while($row=$result_blog->fetch_assoc())
        {
                $arr_bolgID[$i]=$row['blog_nummer'];
                $a[$i]=$row['blog'];
                $b[$i]=$row['col_date'];
                $i++;
        }
        $total = $i ;
        $i=1;
        $j=($seite_nummer*7)-7;
        if(($total-$j)>7){$rest=7+$j;}
        elseif(($total-$j)<7){$rest=$total;}
        else {echo "result0";}
        for($j;$j<$rest;$j++)
                {
                    /*$q='{"row"}';
                    $q1='"button"';
                    $q2='"btn btn btn-danger"';
                    $q3='"delete.php"';*/
                    $var= '<tr>
                    <th scope="row">'.($i++).'</th> 
                    <td> '.$a[$j].'</td>
                    <td> '.$b[$j].'</td> 
                    
                    <td><a href="delete.php? delete_blogid='.$arr_bolgID[$j].'" class="btn btn-outline-danger">DELETE</a>
                    <a href="update.php? update_blogid='.$arr_bolgID[$j].'" class="btn btn-outline-primary">UPDATE</a></td>
                    </tr>';
                    echo $var;
                }            
      //seiten nummer   
    }for($number=1;$number<=$_SESSION['numberr'];$number++){
        echo '<a href="seiten.php? button_nummer='.($number).'" class="btn btn-outline-info">'.($number).'</a>';}

}
?>
            </tbody>
        </table>
   </body>
</html>
