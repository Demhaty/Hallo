-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 05. Nov 2021 um 15:34
-- Server-Version: 10.4.20-MariaDB
-- PHP-Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `projekt`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `adresse`
--

CREATE TABLE `adresse` (
  `adresse_ID` int(11) NOT NULL,
  `strasse` char(50) DEFAULT NULL,
  `hausnummer` int(11) DEFAULT NULL,
  `fk_plz_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `adresse`
--

INSERT INTO `adresse` (`adresse_ID`, `strasse`, `hausnummer`, `fk_plz_ID`) VALUES
(36, 'dsfdsf', 0, 36),
(37, 'gjkjgu', 11, 37),
(38, 'dsfdsf', 0, 38),
(39, 'dsfdsf', 0, 39),
(40, 'dsfdsf', 0, 40),
(41, 'dsfdsf', 0, 41),
(42, 'dsfdsf', 0, 42),
(43, 'dsfdsf', 0, 43),
(44, 'dsfdsf', 0, 44),
(45, 'dsfdsf', 0, 45),
(46, 'dsfdsf', 0, 46);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `anmeldung`
--

CREATE TABLE `anmeldung` (
  `fk_benutzer_ID` int(11) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `pasd` blob NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `anmeldung`
--

INSERT INTO `anmeldung` (`fk_benutzer_ID`, `email`, `pasd`) VALUES
(36, 'o@gmail.de', 0x61333230343830663533343737366264646235636462353462316539336432313061336337643139396538306132336331623231373834393762313834633736),
(37, 'oo@gmail.de', 0x61333230343830663533343737366264646235636462353462316539336432313061336337643139396538306132336331623231373834393762313834633736),
(38, 'y@gmail.de', 0x61333230343830663533343737366264646235636462353462316539336432313061336337643139396538306132336331623231373834393762313834633736),
(39, 'yy@gmail.de', 0x61333230343830663533343737366264646235636462353462316539336432313061336337643139396538306132336331623231373834393762313834633736),
(40, 'g@g.com', 0x61333230343830663533343737366264646235636462353462316539336432313061336337643139396538306132336331623231373834393762313834633736),
(41, 'h@g.com', 0x61333230343830663533343737366264646235636462353462316539336432313061336337643139396538306132336331623231373834393762313834633736),
(43, 'e@ee.com', 0x61333230343830663533343737366264646235636462353462316539336432313061336337643139396538306132336331623231373834393762313834633736),
(44, 'dd@d.de', 0x61333230343830663533343737366264646235636462353462316539336432313061336337643139396538306132336331623231373834393762313834633736),
(46, 'dddd@d.de', 0x61363635613435393230343232663964343137653438363765666463346662386130346131663366666631666130376539393865383666376637613237616533);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `benutzer`
--

CREATE TABLE `benutzer` (
  `benutzer_ID` int(11) NOT NULL,
  `vorname` char(50) DEFAULT NULL,
  `nachname` char(50) DEFAULT NULL,
  `geburtsdatum` date DEFAULT NULL,
  `fk_adresse_ID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `benutzer`
--

INSERT INTO `benutzer` (`benutzer_ID`, `vorname`, `nachname`, `geburtsdatum`, `fk_adresse_ID`) VALUES
(36, 'fdsf', 'sdwqsd', '2021-11-11', NULL),
(37, 'fdsf', 'sdwqsd', '2021-11-13', NULL),
(38, 'fdsf', 'sdwqsd', '2021-11-12', NULL),
(39, 'fdsf', 'sdwqsd', '2021-11-25', NULL),
(40, 'aaa', 'bbbb', '2021-11-10', NULL),
(41, 'aaa', 'bbbb', '2021-11-19', NULL),
(42, 'fdsf', 'sdwqsd', '2021-12-01', NULL),
(43, 'aaa', 'bbbb', '2021-11-11', NULL),
(44, 'aaa', 'bbbb', '2021-11-17', NULL),
(45, 'aaa', 'bbbb', '2021-11-17', NULL),
(46, 'fdsf', 'sdwqsd', '2021-11-17', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `blogg`
--

CREATE TABLE `blogg` (
  `fkk_benutzer_ID` int(11) DEFAULT NULL,
  `blog_nummer` int(11) NOT NULL,
  `blog` char(200) DEFAULT NULL,
  `col_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `blogg`
--

INSERT INTO `blogg` (`fkk_benutzer_ID`, `blog_nummer`, `blog`, `col_date`) VALUES
(43, 54, 'yy', '2021-11-04 08:32:21'),
(43, 55, 'q1', '2021-11-04 08:35:17'),
(36, 61, 'hiiiiiiiiiiiiiiiiiiiiiiiiii', '2021-11-04 08:54:27'),
(36, 62, 'fdhfd', '2021-11-04 08:57:48'),
(36, 63, 'fdhfd', '2021-11-04 08:59:35'),
(36, 64, 't1', '2021-11-04 09:33:03'),
(36, 65, 'w1', '2021-11-04 09:40:03'),
(36, 66, 't1', '2021-11-04 09:41:03'),
(36, 67, 'z1', '2021-11-04 09:41:22'),
(36, 68, 'z1', '2021-11-04 09:41:26'),
(36, 69, 'v', '2021-11-04 09:45:45'),
(36, 70, 'v', '2021-11-04 09:47:45'),
(36, 71, 'f', '2021-11-04 09:47:46'),
(36, 72, 'f', '2021-11-04 09:49:00'),
(36, 73, 'j', '2021-11-04 09:49:47'),
(36, 74, 'io', '2021-11-04 09:49:55'),
(36, 75, 'i', '2021-11-04 09:50:16'),
(36, 76, 'k', '2021-11-04 09:52:09'),
(36, 77, 'z', '2021-11-04 09:53:00'),
(36, 78, 'l\r\n', '2021-11-04 09:53:54'),
(36, 79, 'l', '2021-11-04 09:54:44'),
(36, 80, 'ppp', '2021-11-04 09:55:02'),
(36, 81, 'kkkk', '2021-11-04 09:58:22'),
(36, 82, 'h', '2021-11-04 10:04:10'),
(36, 84, 'j h', '2021-11-04 10:08:00'),
(36, 85, 'mm', '2021-11-04 10:08:09'),
(36, 86, 'jj', '2021-11-04 10:08:52'),
(36, 87, 'jjjjj', '2021-11-04 10:13:12'),
(36, 88, 'bb\r\n', '2021-11-04 10:16:04'),
(36, 89, 'jhhj', '2021-11-04 10:17:49'),
(36, 90, 'kk', '2021-11-04 10:19:15'),
(36, 91, 'hg', '2021-11-04 10:20:51'),
(36, 92, 'vb', '2021-11-04 10:21:53'),
(36, 93, 'ff', '2021-11-04 10:22:23'),
(36, 94, 'f', '2021-11-04 11:31:04'),
(36, 95, 'ff', '2021-11-04 11:31:08'),
(36, 96, 'g', '2021-11-04 11:31:11'),
(36, 97, 'h', '2021-11-04 12:21:51'),
(36, 98, 'bb\r\n', '2021-11-04 12:25:04'),
(36, 99, 'hnh', '2021-11-04 12:26:06'),
(36, 100, 'f', '2021-11-04 12:27:02'),
(36, 101, 'f', '2021-11-04 12:27:35'),
(36, 102, 'f', '2021-11-04 12:28:46'),
(36, 103, 'd', '2021-11-04 12:31:27'),
(36, 104, 'v', '2021-11-04 12:32:04'),
(36, 105, 'gb', '2021-11-04 12:32:30'),
(36, 106, 'ed', '2021-11-04 12:34:13'),
(36, 107, 'g', '2021-11-04 12:42:35'),
(36, 108, 'f', '2021-11-04 12:43:58'),
(36, 109, 'g', '2021-11-04 12:44:25'),
(36, 110, 'gv', '2021-11-04 12:46:35'),
(36, 111, 'i\r\n', '2021-11-04 12:47:17'),
(36, 112, 'fr', '2021-11-04 12:47:43'),
(36, 113, 'k\r\n', '2021-11-04 12:48:33'),
(36, 114, 'g', '2021-11-04 12:49:04'),
(36, 115, 'g', '2021-11-04 12:50:07'),
(36, 116, 'g', '2021-11-04 12:52:50'),
(36, 117, 'gh', '2021-11-04 12:53:38'),
(36, 118, 'gb', '2021-11-04 12:54:27'),
(36, 119, 'f', '2021-11-04 12:57:18'),
(36, 120, 'g', '2021-11-04 12:58:03'),
(36, 121, 'df', '2021-11-04 13:03:57'),
(36, 122, 'g', '2021-11-04 13:04:59'),
(36, 123, 'f', '2021-11-04 13:05:04'),
(36, 125, 'g', '2021-11-04 13:07:06'),
(36, 126, 'g', '2021-11-04 13:08:58'),
(36, 127, 'hg', '2021-11-04 13:09:18'),
(36, 128, 'u', '2021-11-04 13:10:08'),
(36, 129, 'i', '2021-11-04 13:16:32'),
(36, 130, 'gh', '2021-11-04 13:16:47'),
(36, 131, 'tt', '2021-11-04 13:17:25'),
(36, 132, 'g', '2021-11-04 13:20:31'),
(36, 133, 'g', '2021-11-04 13:23:11'),
(36, 134, 'h', '2021-11-04 13:23:41'),
(36, 135, 'h', '2021-11-04 13:24:52'),
(36, 136, 'g', '2021-11-04 13:25:41'),
(36, 137, 'g', '2021-11-04 13:26:34'),
(36, 138, 'g', '2021-11-04 13:28:20'),
(36, 139, 'g', '2021-11-04 13:30:43'),
(36, 140, 'h', '2021-11-04 13:36:58'),
(36, 141, 'b', '2021-11-04 13:38:32'),
(36, 142, 'c', '2021-11-04 13:47:43'),
(36, 144, 'h\r\n', '2021-11-04 13:48:27'),
(36, 148, 'h', '2021-11-04 14:04:08'),
(36, 149, 'g', '2021-11-04 14:06:20'),
(36, 150, 'g', '2021-11-04 14:06:36'),
(36, 151, 'gh', '2021-11-04 14:07:43'),
(36, 152, 'nh\r\n', '2021-11-04 14:11:12'),
(36, 154, 'b', '2021-11-04 14:11:32'),
(36, 156, 'dfe', '2021-11-04 14:14:18'),
(43, 157, 'f', '2021-11-04 14:15:02'),
(43, 158, 'z', '2021-11-04 14:17:40'),
(43, 159, 'h', '2021-11-04 14:21:01'),
(43, 160, 'z', '2021-11-04 14:21:04'),
(43, 161, 'j', '2021-11-04 14:21:10'),
(43, 162, 'j', '2021-11-04 14:23:44'),
(43, 163, 'j', '2021-11-04 14:24:37'),
(43, 164, 'j', '2021-11-04 14:24:41'),
(43, 165, 'j', '2021-11-04 14:25:00'),
(43, 166, 'j', '2021-11-04 14:25:15'),
(43, 167, 'j', '2021-11-04 14:25:21'),
(43, 168, 'j', '2021-11-04 14:25:44'),
(43, 169, 'j', '2021-11-04 14:25:58'),
(43, 170, 'j', '2021-11-04 14:26:43'),
(43, 171, 'j', '2021-11-04 14:27:58'),
(43, 172, 'j', '2021-11-04 14:29:09'),
(43, 173, 'j', '2021-11-04 14:29:20'),
(43, 174, 'j', '2021-11-04 14:29:37'),
(43, 175, 'j', '2021-11-04 14:29:54'),
(38, 176, 'hh', '2021-11-04 14:33:35'),
(NULL, 177, 'v', '2021-11-04 14:34:28'),
(NULL, 178, 'h', '2021-11-04 14:34:33'),
(38, 179, 'gh', '2021-11-04 14:34:57'),
(38, 180, '', '2021-11-04 14:34:59'),
(38, 181, 'gr', '2021-11-04 14:53:13'),
(38, 182, 're', '2021-11-04 14:57:16'),
(38, 183, 'tt', '2021-11-04 14:57:20'),
(38, 184, 'tt', '2021-11-04 14:57:24'),
(38, 185, 'd', '2021-11-04 14:59:21'),
(38, 186, 'qq', '2021-11-04 14:59:26'),
(45, 187, 't', '2021-11-05 12:38:39'),
(45, 188, 'f', '2021-11-05 12:38:47'),
(45, 189, 'g', '2021-11-05 12:38:49'),
(45, 190, 'd', '2021-11-05 12:38:51'),
(45, 191, 'juj', '2021-11-05 12:38:53'),
(45, 192, 'dde', '2021-11-05 12:38:55'),
(45, 193, 'zizuki', '2021-11-05 12:38:59'),
(45, 194, 'rtrt', '2021-11-05 12:39:05'),
(44, 197, 'hgju', '2021-11-05 12:47:39'),
(44, 198, 'zjtj', '2021-11-05 12:47:40'),
(44, 199, 'ztej', '2021-11-05 12:47:42'),
(44, 201, 'ezti', '2021-11-05 12:47:45'),
(44, 202, 'jtzj', '2021-11-05 12:47:47'),
(44, 203, 'eztj', '2021-11-05 12:47:48'),
(44, 204, 'jtz', '2021-11-05 12:47:50'),
(44, 205, 'hjfklzu', '2021-11-05 13:09:42'),
(36, 207, 'fd', '2021-11-05 13:39:13');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `plz`
--

CREATE TABLE `plz` (
  `plz_ID` int(11) NOT NULL,
  `PLZ` int(11) DEFAULT NULL,
  `ort` char(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Daten für Tabelle `plz`
--

INSERT INTO `plz` (`plz_ID`, `PLZ`, `ort`) VALUES
(36, 2332, 'Andorra'),
(37, 1111, 'Andorra'),
(38, 2332, 'Andorra'),
(39, 1111, 'Andorra'),
(40, 765, 'Andorra'),
(41, 34535, 'Andorra'),
(42, 5555, 'Andorra'),
(43, 3435, 'Andorra'),
(44, 2332, 'Andorra'),
(45, 2332, 'Andorra'),
(46, 4232, 'Andorra');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `adresse`
--
ALTER TABLE `adresse`
  ADD PRIMARY KEY (`adresse_ID`),
  ADD KEY `fk_plz_ID` (`fk_plz_ID`);

--
-- Indizes für die Tabelle `anmeldung`
--
ALTER TABLE `anmeldung`
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `fk_benutzer_ID` (`fk_benutzer_ID`);

--
-- Indizes für die Tabelle `benutzer`
--
ALTER TABLE `benutzer`
  ADD PRIMARY KEY (`benutzer_ID`),
  ADD KEY `fk_adresse_ID` (`fk_adresse_ID`);

--
-- Indizes für die Tabelle `blogg`
--
ALTER TABLE `blogg`
  ADD UNIQUE KEY `blog_nummer` (`blog_nummer`),
  ADD KEY `fkk_benutzer_ID` (`fkk_benutzer_ID`);
ALTER TABLE `blogg` ADD FULLTEXT KEY `blog` (`blog`);

--
-- Indizes für die Tabelle `plz`
--
ALTER TABLE `plz`
  ADD PRIMARY KEY (`plz_ID`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `benutzer`
--
ALTER TABLE `benutzer`
  MODIFY `benutzer_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT für Tabelle `blogg`
--
ALTER TABLE `blogg`
  MODIFY `blog_nummer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=208;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `adresse`
--
ALTER TABLE `adresse`
  ADD CONSTRAINT `adresse_ibfk_1` FOREIGN KEY (`fk_plz_ID`) REFERENCES `plz` (`plz_ID`);

--
-- Constraints der Tabelle `anmeldung`
--
ALTER TABLE `anmeldung`
  ADD CONSTRAINT `anmeldung_ibfk_1` FOREIGN KEY (`fk_benutzer_ID`) REFERENCES `benutzer` (`benutzer_ID`);

--
-- Constraints der Tabelle `benutzer`
--
ALTER TABLE `benutzer`
  ADD CONSTRAINT `benutzer_ibfk_1` FOREIGN KEY (`fk_adresse_ID`) REFERENCES `adresse` (`adresse_ID`);

--
-- Constraints der Tabelle `blogg`
--
ALTER TABLE `blogg`
  ADD CONSTRAINT `blogg_ibfk_1` FOREIGN KEY (`fkk_benutzer_ID`) REFERENCES `benutzer` (`benutzer_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
