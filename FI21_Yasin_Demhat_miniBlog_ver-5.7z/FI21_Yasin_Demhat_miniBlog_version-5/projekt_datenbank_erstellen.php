<?php
//Datenbank_______________
$servername = "localhost";
$username = "root";
$password = "";
$dbname="projekt";
function crate_db()
{
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbase="projekt";
    // Create connection
    $conn = new mysqli($servername,$username,$password);
    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Create database
    $sql = "CREATE DATABASE projekt";
    if ($conn->query($sql) === TRUE) {
        echo "Database created successfully </br>";
    }
    else {
        echo "Error creating database: " . $conn->error;
    }
    //$conn->close();
}

crate_db();
$mysqli = new mysqli($GLOBALS['servername'],$GLOBALS['username'],$GLOBALS['password'],$GLOBALS['dbname']);
// Check connection
if ($mysqli -> connect_errno) 
{
    echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
}
//Create table_PLZ
$sql2="CREATE TABLE PLZ(
    plz_ID INT,
    PLZ INT,
    ort CHAR(50),
    PRIMARY KEY(plz_ID) 
    )";
if($mysqli->query($sql2)===true)
{
    echo "Table PLZ created successfully </br>";
} 
else 
{
  echo "Error creating table: " . $mysqli->error;
}
//Create table_Adresse
$sql1="CREATE TABLE adresse(
    adresse_ID int,
    strasse char(50),
    hausnummer int,
    fk_plz_ID int,
    PRIMARY KEY(adresse_ID),
    FOREIGN KEY(fk_plz_ID) REFERENCES PLZ(plz_ID)
    )";
if($mysqli->query($sql1)===true)
{
    echo "Table Adresse created successfully </br>";
} 
else 
{
  echo "Error creating table: " . $mysqli->error;
}
//Create table_Benutzer
$sql="CREATE TABLE Benutzer(
    benutzer_ID INT AUTO_INCREMENT,
    vorname CHAR(50),
    nachname CHAR(50),
    geburtsdatum DATE,
    fk_adresse_ID int,
    PRIMARY KEY (benutzer_ID),
    FOREIGN KEY (fk_adresse_ID) REFERENCES adresse(adresse_ID)
    )";
if($mysqli->query($sql)===true)
{
    echo "Table MyGuests created successfully </br>";
} 
else 
{
  echo "Error creating table: " . $mysqli->error;
}
//Create table_Anmeldung
$sql3="CREATE TABLE Anmeldung(
    fk_benutzer_ID int ,
    email VARCHAR(50),
    pasd BLOB,
    FOREIGN KEY (fk_benutzer_ID) REFERENCES Benutzer(benutzer_ID)
    )";
if($mysqli->query($sql3)===true)
{
    echo "Table MyGuests created successfully </br>";
} 
else 
{
  echo "Error creating table: " . $mysqli->error;
}
?>