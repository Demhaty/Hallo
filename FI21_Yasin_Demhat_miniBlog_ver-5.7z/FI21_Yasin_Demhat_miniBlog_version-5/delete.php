<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "projekt";


$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) 
{
    die("Connection failed: " . $conn->connect_error);
}
if(isset($_REQUEST['delete_blogid']))
{
    $delete_blog_nummer=$_REQUEST['delete_blogid'];
    $delete_blog = $conn->prepare("DELETE FROM blogg  WHERE blog_nummer=".$delete_blog_nummer."");
    $delete_blog->execute();
    
    //echo "Das Blog mit den Nummer:".$delete_blog_nummer." wurde erfolglich gelöscht!";
    header("location:index4.php");   
}
?>