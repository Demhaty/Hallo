<?php
//echo $_REQUEST['benutzerID'];
if(isset($_REQUEST['benutzerID']))
{
    session_unset();
    session_destroy();
    header('location: index.php');
}
?>